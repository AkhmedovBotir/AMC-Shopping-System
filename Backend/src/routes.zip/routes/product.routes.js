const express = require('express');
const Product = require('../models/product.model');
const Category = require('../models/category.model');
const { verifyToken, adminAuth } = require('../middleware/auth.middleware');

const router = express.Router();

// Yangi mahsulot yaratish
router.post('/', verifyToken, adminAuth, async (req, res) => {
    try {
        const { category, subcategory, name, price, unit, unitSize, inventory } = req.body;

        // Kategoriya va subkategoriyani tekshirish
        const categoryDoc = await Category.findById(category);
        if (!categoryDoc) {
            return res.status(404).json({ 
                success: false, 
                message: 'Kategoriya topilmadi' 
            });
        }

        // Subkategoriya kiritilgan bo'lsa tekshirish
        if (subcategory) {
            const subcategoryExists = categoryDoc.subcategories.some(
                sub => sub._id.toString() === subcategory
            );
            if (!subcategoryExists) {
                return res.status(404).json({ 
                    success: false, 
                    message: 'Subkategoriya topilmadi' 
                });
            }
        }

        // Mahsulot yaratish
        const product = new Product({
            name,
            category,
            subcategory,  // Subkategoriya ID string sifatida saqlanadi
            price,
            unit,
            unitSize,
            inventory
        });

        await product.save();
        
        // To'liq ma'lumotlarni olish uchun populate
        await product.populate([
            { path: 'category', select: '_id name' },
            { path: 'subcategoryInfo', select: 'subcategories' }
        ]);

        // WebSocket orqali xabar yuborish
        if (req.app.get('wsHandler')) {
            req.app.get('wsHandler').notifyProductCreated(product);
        }

        res.status(201).json({
            success: true,
            data: product
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            message: error.message
        });
    }
});

// Barcha mahsulotlarni olish
router.get('/', verifyToken, async (req, res) => {
    try {
        const { 
            category, 
            subcategory, 
            search,
            sort = 'name',
            order = 'asc',
            page = 1,
            limit = 10
        } = req.query;

        // Filter
        const filter = {};
        if (category) filter.category = category;
        if (subcategory) filter.subcategory = subcategory;
        if (search) {
            filter.name = { 
                $regex: search, 
                $options: 'i' 
            };
        }

        // Sort
        const sortOptions = {};
        sortOptions[sort] = order === 'asc' ? 1 : -1;

        // Pagination
        const skip = (page - 1) * limit;
        
        // Get products with total count
        const [products, total] = await Promise.all([
            Product.find(filter)
                .sort(sortOptions)
                .skip(skip)
                .limit(parseInt(limit))
                .populate('category', '_id name')
                .populate('subcategory', '_id name'),
            Product.countDocuments(filter)
        ]);

        res.json({
            success: true,
            data: {
                items: products,
                total,
                page: parseInt(page),
                pages: Math.ceil(total / limit)
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// Mahsulotni yangilash
router.put('/:id', verifyToken, adminAuth, async (req, res) => {
    try {
        const { id } = req.params;
        const updates = req.body;
        const allowedUpdates = ['name', 'category', 'subcategory', 'price', 'unit', 'unitSize', 'inventory'];
        
        // Faqat ruxsat etilgan maydonlarni ajratib olish
        const updateData = Object.keys(updates)
            .filter(key => allowedUpdates.includes(key))
            .reduce((obj, key) => {
                obj[key] = updates[key];
                return obj;
            }, {});

        // Agar kategoriya yangilanayotgan bo'lsa
        if (updateData.category) {
            const categoryDoc = await Category.findById(updateData.category);
            if (!categoryDoc) {
                return res.status(404).json({
                    success: false,
                    message: 'Kategoriya topilmadi'
                });
            }

            // Agar subkategoriya ham yangilanayotgan bo'lsa
            if (updateData.subcategory) {
                const subcategoryExists = categoryDoc.subcategories.some(
                    sub => sub._id.toString() === updateData.subcategory
                );
                if (!subcategoryExists) {
                    return res.status(404).json({
                        success: false,
                        message: 'Subkategoriya topilmadi'
                    });
                }
            }
        } 
        // Agar faqat subkategoriya yangilanayotgan bo'lsa
        else if (updateData.subcategory) {
            const product = await Product.findById(id);
            if (!product) {
                return res.status(404).json({
                    success: false,
                    message: 'Mahsulot topilmadi'
                });
            }

            const categoryDoc = await Category.findById(product.category);
            const subcategoryExists = categoryDoc.subcategories.some(
                sub => sub._id.toString() === updateData.subcategory
            );
            if (!subcategoryExists) {
                return res.status(404).json({
                    success: false,
                    message: 'Subkategoriya topilmadi'
                });
            }
        }

        // Mahsulotni yangilash
        const product = await Product.findByIdAndUpdate(
            id,
            updateData,
            { 
                new: true,  // Yangilangan mahsulotni qaytarish
                runValidators: true  // Validatsiyalarni tekshirish
            }
        );

        if (!product) {
            return res.status(404).json({
                success: false,
                message: 'Mahsulot topilmadi'
            });
        }

        // To'liq ma'lumotlarni olish uchun populate
        await product.populate([
            { path: 'category', select: '_id name' },
            { path: 'subcategoryInfo', select: 'subcategories' }
        ]);

        // WebSocket orqali xabar yuborish
        if (req.app.get('wsHandler')) {
            req.app.get('wsHandler').notifyProductUpdated(product);
        }

        res.json({
            success: true,
            data: product
        });

    } catch (error) {
        res.status(400).json({
            success: false,
            message: error.message
        });
    }
});

// Mahsulotni o'chirish
router.delete('/:id', verifyToken, adminAuth, async (req, res) => {
    try {
        const product = await Product.findByIdAndDelete(req.params.id);
        
        if (!product) {
            return res.status(404).json({
                success: false,
                message: 'Mahsulot topilmadi'
            });
        }

        // WebSocket orqali xabar yuborish
        if (req.wsHandlers) {
            req.wsHandlers.notifyProductDeleted(product._id);
        }

        res.json({
            success: true,
            message: 'Mahsulot muvaffaqiyatli o\'chirildi'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// Kategoriya bo'yicha mahsulotlarni olish
router.get('/category/:categoryId', verifyToken, async (req, res) => {
    try {
        const { 
            sort = 'name',
            order = 'asc',
            page = 1,
            limit = 10
        } = req.query;

        // Sort
        const sortOptions = {};
        sortOptions[sort] = order === 'asc' ? 1 : -1;

        // Pagination
        const skip = (page - 1) * limit;

        // Get products with total count
        const [products, total] = await Promise.all([
            Product.find({ category: req.params.categoryId })
                .sort(sortOptions)
                .skip(skip)
                .limit(parseInt(limit))
                .populate('category', '_id name')
                .populate('subcategory', '_id name'),
            Product.countDocuments({ category: req.params.categoryId })
        ]);

        res.json({
            success: true,
            data: {
                items: products,
                total,
                page: parseInt(page),
                pages: Math.ceil(total / limit)
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// Subkategoriya bo'yicha mahsulotlarni olish
router.get('/subcategory/:subcategoryId', verifyToken, async (req, res) => {
    try {
        const { 
            sort = 'name',
            order = 'asc',
            page = 1,
            limit = 10
        } = req.query;

        // Sort
        const sortOptions = {};
        sortOptions[sort] = order === 'asc' ? 1 : -1;

        // Pagination
        const skip = (page - 1) * limit;

        // Get products with total count
        const [products, total] = await Promise.all([
            Product.find({ subcategory: req.params.subcategoryId })
                .sort(sortOptions)
                .skip(skip)
                .limit(parseInt(limit))
                .populate('category', '_id name')
                .populate('subcategory', '_id name'),
            Product.countDocuments({ subcategory: req.params.subcategoryId })
        ]);

        res.json({
            success: true,
            data: {
                items: products,
                total,
                page: parseInt(page),
                pages: Math.ceil(total / limit)
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// Kam qolgan mahsulotlarni olish
router.get('/low-inventory', verifyToken, adminAuth, async (req, res) => {
    try {
        const { 
            min = 10,
            sort = 'inventory',
            order = 'asc',
            page = 1,
            limit = 10
        } = req.query;

        // Sort
        const sortOptions = {};
        sortOptions[sort] = order === 'asc' ? 1 : -1;

        // Pagination
        const skip = (page - 1) * limit;

        // Get products with total count
        const [products, total] = await Promise.all([
            Product.find({ inventory: { $lte: parseInt(min) } })
                .sort(sortOptions)
                .skip(skip)
                .limit(parseInt(limit))
                .populate('category', '_id name')
                .populate('subcategory', '_id name'),
            Product.countDocuments({ inventory: { $lte: parseInt(min) } })
        ]);

        res.json({
            success: true,
            data: {
                items: products,
                total,
                page: parseInt(page),
                pages: Math.ceil(total / limit)
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// Inventoryni yangilash
router.post('/:id/inventory', verifyToken, adminAuth, async (req, res) => {
    try {
        const { quantity, isAddition = true } = req.body;
        if (!quantity || quantity <= 0) {
            return res.status(400).json({ 
                success: false, 
                message: 'Noto\'g\'ri miqdor' 
            });
        }

        const product = await Product.findById(req.params.id);
        if (!product) {
            return res.status(404).json({
                success: false,
                message: 'Mahsulot topilmadi'
            });
        }

        await product.updateInventory(quantity, isAddition);
        await product.populate('category', '_id name');
        await product.populate('subcategory', '_id name');

        // WebSocket orqali xabar yuborish
        if (req.wsHandlers) {
            req.wsHandlers.notifyProductUpdated(product);
        }

        res.json({
            success: true,
            data: product
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            message: error.message
        });
    }
});

// Mahsulotni ID bo'yicha olish
router.get('/:id', verifyToken, async (req, res) => {
    try {
        const product = await Product.findById(req.params.id)
            .populate('category', '_id name')
            .populate('subcategory', '_id name');

        if (!product) {
            return res.status(404).json({
                success: false,
                message: 'Mahsulot topilmadi'
            });
        }

        res.json({
            success: true,
            data: product
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

module.exports = router;
