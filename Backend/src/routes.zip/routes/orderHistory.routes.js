const router = require('express').Router();
const OrderHistory = require('../models/orderHistory.model');
const Counter = require('../models/counter.model');
const Product = require('../models/product.model');
const mongoose = require('mongoose');
const { verifyToken } = require('../middleware/auth.middleware');

// Counter orqali yangi orderId olish
async function getNextOrderId() {
    const counter = await Counter.findByIdAndUpdate(
        'draftOrderId',
        { $inc: { seq: 1 } },
        { new: true, upsert: true }
    );
    return counter.seq;
}

// Barcha buyurtmalar tarixini olish
router.get('/', verifyToken, async (req, res) => {
    try {
        const {
            page = 1,
            limit = 20,
            startDate,
            endDate
        } = req.query;

        // Filter yaratish
        let filter = {};
        
        // Agar admin bo'lmasa, faqat o'z buyurtmalarini ko'rsatish
        if (!req.user.isAdmin) {
            filter.seller = new mongoose.Types.ObjectId(req.user._id);
        }

        // Sana filtri
        if (startDate && endDate) {
            const startDateTime = new Date(startDate);
            startDateTime.setHours(0, 0, 0, 0);

            const endDateTime = new Date(endDate);
            endDateTime.setHours(23, 59, 59, 999);

            filter.createdAt = {
                $gte: startDateTime,
                $lte: endDateTime
            };
            console.log('Date filter:', JSON.stringify(filter, null, 2));
        }

        // Filter bilan buyurtmalarni olamiz
        const orders = await OrderHistory.find(filter)
            .sort({ createdAt: -1 })
            .skip((page - 1) * limit)
            .limit(parseInt(limit))
            .populate({
                path: 'products.productId',
                select: 'name price unit unitSize'
            })
            .populate({
                path: 'seller',
                select: 'name username status',
                model: 'Seller'
            })
            .lean();

        const total = await OrderHistory.countDocuments(filter);

        console.log('Final filtered Orders:', orders.length);
        console.log('Total count:', total);

        res.json({
            success: true,
            data: {
                orders,
                pagination: {
                    total,
                    pages: Math.ceil(total / limit),
                    currentPage: parseInt(page),
                    perPage: parseInt(limit)
                }
            }
        });
    } catch (error) {
        console.error('Error fetching orders:', error);
        res.status(500).json({
            success: false,
            message: 'Buyurtmalar olishda xatolik yuz berdi',
            error: error.message
        });
    }
});

// To'g'ridan-to'g'ri buyurtma berish
router.post('/direct-order', verifyToken, async (req, res) => {
    try {
        const { products, totalSum, table, computerId = 'DEFAULT' } = req.body;

        // Mahsulotlar inventoryni tekshirish va yangilash
        for (const item of products) {
            const product = await Product.findById(item.productId);
            if (!product) {
                return res.status(404).json({
                    success: false,
                    message: `Mahsulot topilmadi: ${item.productId}`
                });
            }

            // Inventoryni tekshirish
            if (product.inventory < item.quantity) {
                return res.status(400).json({
                    success: false,
                    message: `${product.name} mahsulotidan yetarli miqdor yo'q. Mavjud: ${product.inventory}`
                });
            }

            // Inventoryni yangilash
            product.inventory -= item.quantity;
            await product.save();
        }

        // Counter orqali yangi orderId olish
        const orderId = await getNextOrderId();

        console.log('Creating order with seller:', {
            sellerId: req.user._id,
            sellerName: req.user.name
        });

        // Yangi buyurtma yaratish
        const order = new OrderHistory({
            orderId,
            computerId,
            seller: new mongoose.Types.ObjectId(req.user._id),
            table,
            products: products.map(item => ({
                productId: new mongoose.Types.ObjectId(item.productId),
                name: item.name,
                quantity: item.quantity,
                price: item.price,
                unit: item.unit,
                unitSize: item.unitSize
            })),
            totalSum,
            status: 'completed',
            paymentMethod: 'cash',
            completedAt: new Date()
        });

        const savedOrder = await order.save();
        console.log('Created order:', {
            orderId: savedOrder.orderId,
            sellerId: savedOrder.seller,
            sellerInfo: await OrderHistory.findById(savedOrder._id).populate('seller', 'name username status')
        });

        // Yaratilgan buyurtmani to'liq ma'lumotlar bilan qaytarish
        const populatedOrder = await OrderHistory.findById(order._id)
            .populate({
                path: 'products.productId',
                select: 'name price unit unitSize'
            })
            .lean();

        res.status(201).json({
            success: true,
            data: populatedOrder
        });
    } catch (error) {
        console.error('Error creating order:', error);
        res.status(400).json({
            success: false,
            message: error.message
        });
    }
});

// Barcha tasdiqlangan buyurtmalarni olish
router.get('/completed-orders', verifyToken, async (req, res) => {
    try {
        const { startDate, endDate, page = 1, limit = 10 } = req.query;
        const skip = (page - 1) * limit;
        
        // Filter yaratish
        const filter = { status: 'completed' };
        
        // Sana bo'yicha filtrlash
        if (startDate && endDate) {
            const startDateTime = new Date(startDate);
            startDateTime.setHours(0, 0, 0, 0);

            const endDateTime = new Date(endDate);
            endDateTime.setHours(23, 59, 59, 999);

            filter.createdAt = {
                $gte: startDateTime,
                $lte: endDateTime
            };
        }

        // Buyurtmalar sonini olish
        const total = await OrderHistory.countDocuments(filter);

        // Buyurtmalarni olish
        const orders = await OrderHistory.find(filter)
            .populate('seller', 'name email phone role')
            .populate({
                path: 'products.productId',
                select: 'name price unit unitSize',
                populate: {
                    path: 'category',
                    select: 'name'
                }
            })
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(parseInt(limit));

        // Umumiy summa va mahsulotlar sonini hisoblash
        const stats = await OrderHistory.aggregate([
            { $match: filter },
            {
                $group: {
                    _id: null,
                    totalAmount: { $sum: '$totalSum' },
                    totalOrders: { $sum: 1 },
                    totalProducts: { $sum: { $size: '$products' } }
                }
            }
        ]);

        // To'lov usuli bo'yicha statistika
        const paymentStats = await OrderHistory.aggregate([
            { $match: filter },
            {
                $group: {
                    _id: '$paymentMethod',
                    totalAmount: { $sum: '$totalSum' },
                    count: { $sum: 1 }
                }
            }
        ]);

        res.json({
            success: true,
            data: {
                orders,
                pagination: {
                    total,
                    pages: Math.ceil(total / limit),
                    currentPage: parseInt(page),
                    perPage: parseInt(limit)
                },
                stats: stats[0] || {
                    totalAmount: 0,
                    totalOrders: 0,
                    totalProducts: 0
                },
                paymentStats: paymentStats.reduce((acc, curr) => {
                    acc[curr._id] = {
                        totalAmount: curr.totalAmount,
                        count: curr.count
                    };
                    return acc;
                }, {})
            }
        });

    } catch (error) {
        console.error('Get completed orders error:', error);
        res.status(500).json({
            success: false,
            message: 'Buyurtmalarni olishda xatolik yuz berdi'
        });
    }
});

// Bitta buyurtma tarixini olish
router.get('/:id', verifyToken, async (req, res) => {
    try {
        const order = await OrderHistory.findOne({
            _id: req.params.id,
            seller: new mongoose.Types.ObjectId(req.user._id)
        })
        .populate({
            path: 'products.productId',
            select: 'name price unit unitSize'
        })
        .lean();

        if (!order) {
            return res.status(404).json({
                success: false,
                message: 'Buyurtma topilmadi'
            });
        }

        res.json({
            success: true,
            data: order
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

module.exports = router;
