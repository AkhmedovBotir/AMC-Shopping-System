const express = require('express');
const Product = require('../models/product.model');
const Category = require('../models/category.model');
const OrderHistory = require('../models/orderHistory.model');
const User = require('../models/user.model');
const { verifyToken, adminAuth } = require('../middleware/auth.middleware');

const router = express.Router();

// 1. Ombordagi barcha statistikani olish
router.get('/warehouse', verifyToken, async (req, res) => {
    try {
        // Barcha mahsulotlar bo'yicha statistika
        const productsStats = await Product.aggregate([
            {
                $group: {
                    _id: null,
                    totalProducts: { $sum: 1 },
                    totalQuantity: { $sum: '$inventory' },
                    totalValue: { 
                        $sum: { $multiply: ['$inventory', '$price'] }
                    }
                }
            }
        ]);

        // Kategoriyalar bo'yicha statistika
        const categoryStats = await Product.aggregate([
            {
                $lookup: {
                    from: 'categories',
                    localField: 'category',
                    foreignField: '_id',
                    as: 'category'
                }
            },
            {
                $unwind: '$category'
            },
            {
                $group: {
                    _id: {
                        categoryId: '$category._id',
                        categoryName: '$category.name'
                    },
                    productsCount: { $sum: 1 },
                    totalQuantity: { $sum: '$inventory' },
                    totalValue: { 
                        $sum: { $multiply: ['$inventory', '$price'] }
                    }
                }
            },
            {
                $project: {
                    _id: 0,
                    categoryId: '$_id.categoryId',
                    categoryName: '$_id.categoryName',
                    productsCount: 1,
                    totalQuantity: 1,
                    totalValue: 1
                }
            }
        ]);

        // Eng ko'p qolgan mahsulotlar (top 10)
        const topProducts = await Product.aggregate([
            {
                $lookup: {
                    from: 'categories',
                    localField: 'category',
                    foreignField: '_id',
                    as: 'category'
                }
            },
            {
                $unwind: '$category'
            },
            {
                $sort: { inventory: -1 }
            },
            {
                $limit: 10
            },
            {
                $project: {
                    _id: 1,
                    name: 1,
                    inventory: 1,
                    price: 1,
                    totalValue: { $multiply: ['$inventory', '$price'] },
                    category: '$category.name',
                    unit: 1,
                    unitSize: 1
                }
            }
        ]);

        // Kam qolgan mahsulotlar (10 ta)
        const lowStockProducts = await Product.aggregate([
            {
                $match: {
                    inventory: { $lt: 10 }
                }
            },
            {
                $lookup: {
                    from: 'categories',
                    localField: 'category',
                    foreignField: '_id',
                    as: 'category'
                }
            },
            {
                $unwind: '$category'
            },
            {
                $project: {
                    _id: 1,
                    name: 1,
                    inventory: 1,
                    price: 1,
                    totalValue: { $multiply: ['$inventory', '$price'] },
                    category: '$category.name',
                    unit: 1,
                    unitSize: 1
                }
            },
            {
                $sort: { inventory: 1 }
            },
            {
                $limit: 10
            }
        ]);

        // Mahsulotlar bo'yicha sotuvlar tarixi (oxirgi 30 kun)
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

        const productSalesHistory = await OrderHistory.aggregate([
            {
                $match: {
                    createdAt: { $gte: thirtyDaysAgo }
                }
            },
            {
                $unwind: '$products'
            },
            {
                $group: {
                    _id: {
                        productId: '$products.productId',
                        date: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } }
                    },
                    quantity: { $sum: '$products.quantity' },
                    amount: { $sum: { $multiply: ['$products.quantity', '$products.price'] } }
                }
            },
            {
                $group: {
                    _id: '$_id.productId',
                    dailyStats: {
                        $push: {
                            date: '$_id.date',
                            quantity: '$quantity',
                            amount: '$amount'
                        }
                    },
                    totalQuantitySold: { $sum: '$quantity' },
                    totalAmountSold: { $sum: '$amount' }
                }
            },
            {
                $lookup: {
                    from: 'products',
                    localField: '_id',
                    foreignField: '_id',
                    as: 'product'
                }
            },
            {
                $unwind: '$product'
            },
            {
                $lookup: {
                    from: 'categories',
                    localField: 'product.category',
                    foreignField: '_id',
                    as: 'category'
                }
            },
            {
                $unwind: '$category'
            },
            {
                $project: {
                    name: '$product.name',
                    inventory: '$product.inventory',
                    price: '$product.price',
                    category: '$category.name',
                    unit: '$product.unit',
                    unitSize: '$product.unitSize',
                    dailyStats: 1,
                    totalQuantitySold: 1,
                    totalAmountSold: 1,
                    averageDailySales: { $divide: ['$totalQuantitySold', 30] }
                }
            },
            {
                $sort: { totalQuantitySold: -1 }
            }
        ]);

        res.json({
            success: true,
            data: {
                overview: productsStats[0] || {
                    totalProducts: 0,
                    totalQuantity: 0,
                    totalValue: 0
                },
                categoryStats,
                topProducts,
                lowStockProducts,
                productSalesHistory
            }
        });

    } catch (error) {
        console.error('Warehouse statistics error:', error);
        res.status(500).json({
            success: false,
            message: 'Statistikani olishda xatolik yuz berdi'
        });
    }
});

// 2. Sotuvlar statistikasi
router.get('/sales', verifyToken, async (req, res) => {
    try {
        const { startDate, endDate } = req.query;
        const dateFilter = {};
        
        if (startDate && endDate) {
            dateFilter.createdAt = {
                $gte: new Date(startDate),
                $lte: new Date(endDate)
            };
        }

        // Umumiy sotuvlar statistikasi
        const salesStats = await OrderHistory.aggregate([
            { $match: dateFilter },
            {
                $group: {
                    _id: null,
                    totalSales: { $sum: 1 },
                    totalAmount: { $sum: '$totalSum' }
                }
            }
        ]);

        // Kunlik sotuvlar
        const dailySales = await OrderHistory.aggregate([
            { $match: dateFilter },
            {
                $group: {
                    _id: {
                        $dateToString: { format: "%Y-%m-%d", date: "$createdAt" }
                    },
                    salesCount: { $sum: 1 },
                    totalAmount: { $sum: '$totalSum' }
                }
            },
            { $sort: { _id: -1 } },
            { $limit: 30 }
        ]);

        // Eng ko'p sotilgan mahsulotlar
        const topSellingProducts = await OrderHistory.aggregate([
            { $match: dateFilter },
            { $unwind: '$products' },
            {
                $group: {
                    _id: '$products.productId',
                    productName: { $first: '$products.name' },
                    totalQuantity: { $sum: '$products.quantity' },
                    totalAmount: { $sum: { $multiply: ['$products.price', '$products.quantity'] } }
                }
            },
            { $sort: { totalQuantity: -1 } },
            { $limit: 10 }
        ]);

        res.json({
            success: true,
            data: {
                overview: salesStats[0] || {
                    totalSales: 0,
                    totalAmount: 0
                },
                dailySales,
                topSellingProducts
            }
        });

    } catch (error) {
        console.error('Sales statistics error:', error);
        res.status(500).json({
            success: false,
            message: 'Sotuvlar statistikasini olishda xatolik yuz berdi'
        });
    }
});

// 3. Kunlik statistika
router.get('/daily', verifyToken, async (req, res) => {
    try {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);

        // Asosiy statistika
        const dailyStats = await OrderHistory.aggregate([
            {
                $match: {
                    createdAt: { $gte: today, $lt: tomorrow }
                }
            },
            {
                $group: {
                    _id: null,
                    totalSales: { $sum: 1 },
                    totalAmount: { $sum: '$totalSum' }
                }
            }
        ]);

        // Soatlik statistika
        const hourlyStats = await OrderHistory.aggregate([
            {
                $match: {
                    createdAt: { $gte: today, $lt: tomorrow }
                }
            },
            {
                $group: {
                    _id: { $hour: '$createdAt' },
                    salesCount: { $sum: 1 },
                    totalAmount: { $sum: '$totalSum' }
                }
            },
            { $sort: { _id: 1 } }
        ]);

        // To'lov usuli bo'yicha statistika
        const paymentStats = await OrderHistory.aggregate([
            {
                $match: {
                    createdAt: { $gte: today, $lt: tomorrow }
                }
            },
            {
                $group: {
                    _id: '$paymentMethod',
                    totalAmount: { $sum: '$totalSum' }
                }
            }
        ]);

        // Eng ko'p sotilgan mahsulotlar
        const topProducts = await OrderHistory.aggregate([
            {
                $match: {
                    createdAt: { $gte: today, $lt: tomorrow }
                }
            },
            { $unwind: '$products' },
            {
                $group: {
                    _id: '$products.productId',
                    name: { $first: '$products.name' },
                    totalQuantity: { $sum: '$products.quantity' },
                    totalAmount: { $sum: { $multiply: ['$products.quantity', '$products.price'] } }
                }
            },
            { $sort: { totalQuantity: -1 } },
            { $limit: 10 }
        ]);

        // Kam qolgan mahsulotlar
        const lowStockProducts = await Product.aggregate([
            {
                $match: {
                    inventory: { $lt: 10 }
                }
            },
            {
                $lookup: {
                    from: 'categories',
                    localField: 'category',
                    foreignField: '_id',
                    as: 'category'
                }
            },
            { $unwind: '$category' },
            {
                $project: {
                    name: 1,
                    inventory: 1,
                    price: 1,
                    category: '$category.name'
                }
            },
            { $sort: { inventory: 1 } },
            { $limit: 10 }
        ]);

        // Mahsulotlar bo'yicha sotuvlar tarixi
        const productSalesHistory = await OrderHistory.aggregate([
            {
                $match: {
                    createdAt: { $gte: today, $lt: tomorrow }
                }
            },
            { $unwind: '$products' },
            {
                $group: {
                    _id: {
                        productId: '$products.productId',
                        hour: { $hour: '$createdAt' }
                    },
                    name: { $first: '$products.name' },
                    quantity: { $sum: '$products.quantity' },
                    amount: { $sum: { $multiply: ['$products.quantity', '$products.price'] } }
                }
            },
            {
                $group: {
                    _id: '$_id.productId',
                    name: { $first: '$name' },
                    hourlyStats: {
                        $push: {
                            hour: '$_id.hour',
                            quantity: '$quantity',
                            amount: '$amount'
                        }
                    },
                    totalQuantity: { $sum: '$quantity' },
                    totalAmount: { $sum: '$amount' }
                }
            },
            { $sort: { totalQuantity: -1 } }
        ]);

        res.json({
            success: true,
            data: {
                totalSales: dailyStats[0]?.totalSales || 0,
                totalAmount: dailyStats[0]?.totalAmount || 0,
                hourlyStats: hourlyStats.map(stat => ({
                    hour: stat._id,
                    salesCount: stat.salesCount,
                    totalAmount: stat.totalAmount
                })),
                paymentMethods: Object.fromEntries(
                    paymentStats.map(stat => [stat._id, stat.totalAmount])
                ),
                topProducts,
                lowStockProducts,
                productSalesHistory
            }
        });

    } catch (error) {
        console.error('Daily statistics error:', error);
        res.status(500).json({
            success: false,
            message: 'Kunlik statistikani olishda xatolik yuz berdi'
        });
    }
});

// 4. Haftalik statistika
router.get('/weekly', verifyToken, async (req, res) => {
    try {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const weekStart = new Date(today);
        weekStart.setDate(weekStart.getDate() - weekStart.getDay());
        const weekEnd = new Date(weekStart);
        weekEnd.setDate(weekEnd.getDate() + 7);

        // Asosiy statistika
        const weeklyStats = await OrderHistory.aggregate([
            {
                $match: {
                    createdAt: { $gte: weekStart, $lt: weekEnd }
                }
            },
            {
                $group: {
                    _id: null,
                    totalSales: { $sum: 1 },
                    totalAmount: { $sum: '$totalSum' }
                }
            }
        ]);

        // Kunlik statistika
        const dailyStats = await OrderHistory.aggregate([
            {
                $match: {
                    createdAt: { $gte: weekStart, $lt: weekEnd }
                }
            },
            {
                $group: {
                    _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } },
                    salesCount: { $sum: 1 },
                    totalAmount: { $sum: '$totalSum' }
                }
            },
            { $sort: { _id: 1 } }
        ]);

        // To'lov usuli bo'yicha statistika
        const paymentStats = await OrderHistory.aggregate([
            {
                $match: {
                    createdAt: { $gte: weekStart, $lt: weekEnd }
                }
            },
            {
                $group: {
                    _id: '$paymentMethod',
                    totalAmount: { $sum: '$totalSum' }
                }
            }
        ]);

        // Eng ko'p sotilgan mahsulotlar
        const topProducts = await OrderHistory.aggregate([
            {
                $match: {
                    createdAt: { $gte: weekStart, $lt: weekEnd }
                }
            },
            { $unwind: '$products' },
            {
                $group: {
                    _id: '$products.productId',
                    name: { $first: '$products.name' },
                    totalQuantity: { $sum: '$products.quantity' },
                    totalAmount: { $sum: { $multiply: ['$products.quantity', '$products.price'] } }
                }
            },
            { $sort: { totalQuantity: -1 } },
            { $limit: 10 }
        ]);

        // Kam qolgan mahsulotlar
        const lowStockProducts = await Product.aggregate([
            {
                $match: {
                    inventory: { $lt: 10 }
                }
            },
            {
                $lookup: {
                    from: 'categories',
                    localField: 'category',
                    foreignField: '_id',
                    as: 'category'
                }
            },
            { $unwind: '$category' },
            {
                $project: {
                    name: 1,
                    inventory: 1,
                    price: 1,
                    category: '$category.name'
                }
            },
            { $sort: { inventory: 1 } },
            { $limit: 10 }
        ]);

        // Mahsulotlar bo'yicha sotuvlar tarixi
        const productSalesHistory = await OrderHistory.aggregate([
            {
                $match: {
                    createdAt: { $gte: weekStart, $lt: weekEnd }
                }
            },
            { $unwind: '$products' },
            {
                $group: {
                    _id: {
                        productId: '$products.productId',
                        date: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } }
                    },
                    name: { $first: '$products.name' },
                    quantity: { $sum: '$products.quantity' },
                    amount: { $sum: { $multiply: ['$products.quantity', '$products.price'] } }
                }
            },
            {
                $group: {
                    _id: '$_id.productId',
                    name: { $first: '$name' },
                    dailyStats: {
                        $push: {
                            date: '$_id.date',
                            quantity: '$quantity',
                            amount: '$amount'
                        }
                    },
                    totalQuantity: { $sum: '$quantity' },
                    totalAmount: { $sum: '$amount' }
                }
            },
            { $sort: { totalQuantity: -1 } }
        ]);

        res.json({
            success: true,
            data: {
                totalSales: weeklyStats[0]?.totalSales || 0,
                totalAmount: weeklyStats[0]?.totalAmount || 0,
                dailyStats: dailyStats.map(stat => ({
                    date: stat._id,
                    salesCount: stat.salesCount,
                    totalAmount: stat.totalAmount
                })),
                paymentMethods: Object.fromEntries(
                    paymentStats.map(stat => [stat._id, stat.totalAmount])
                ),
                topProducts,
                lowStockProducts,
                productSalesHistory
            }
        });

    } catch (error) {
        console.error('Weekly statistics error:', error);
        res.status(500).json({
            success: false,
            message: 'Haftalik statistikani olishda xatolik yuz berdi'
        });
    }
});

// 5. Oylik statistika
router.get('/monthly', verifyToken, async (req, res) => {
    try {
        const today = new Date();
        const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
        const monthEnd = new Date(today.getFullYear(), today.getMonth() + 1, 0);

        // Asosiy statistika
        const monthlyStats = await OrderHistory.aggregate([
            {
                $match: {
                    createdAt: { $gte: monthStart, $lte: monthEnd }
                }
            },
            {
                $group: {
                    _id: null,
                    totalSales: { $sum: 1 },
                    totalAmount: { $sum: '$totalSum' }
                }
            }
        ]);

        // Haftalik statistika
        const weeklyStats = await OrderHistory.aggregate([
            {
                $match: {
                    createdAt: { $gte: monthStart, $lte: monthEnd }
                }
            },
            {
                $group: {
                    _id: { $week: '$createdAt' },
                    salesCount: { $sum: 1 },
                    totalAmount: { $sum: '$totalSum' }
                }
            },
            { $sort: { _id: 1 } }
        ]);

        // To'lov usuli bo'yicha statistika
        const paymentStats = await OrderHistory.aggregate([
            {
                $match: {
                    createdAt: { $gte: monthStart, $lte: monthEnd }
                }
            },
            {
                $group: {
                    _id: '$paymentMethod',
                    totalAmount: { $sum: '$totalSum' }
                }
            }
        ]);

        // Eng ko'p sotilgan mahsulotlar
        const topProducts = await OrderHistory.aggregate([
            {
                $match: {
                    createdAt: { $gte: monthStart, $lte: monthEnd }
                }
            },
            { $unwind: '$products' },
            {
                $group: {
                    _id: '$products.productId',
                    name: { $first: '$products.name' },
                    totalQuantity: { $sum: '$products.quantity' },
                    totalAmount: { $sum: { $multiply: ['$products.quantity', '$products.price'] } }
                }
            },
            { $sort: { totalQuantity: -1 } },
            { $limit: 10 }
        ]);

        // Kam qolgan mahsulotlar
        const lowStockProducts = await Product.aggregate([
            {
                $match: {
                    inventory: { $lt: 10 }
                }
            },
            {
                $lookup: {
                    from: 'categories',
                    localField: 'category',
                    foreignField: '_id',
                    as: 'category'
                }
            },
            { $unwind: '$category' },
            {
                $project: {
                    name: 1,
                    inventory: 1,
                    price: 1,
                    category: '$category.name'
                }
            },
            { $sort: { inventory: 1 } },
            { $limit: 10 }
        ]);

        // Mahsulotlar bo'yicha sotuvlar tarixi
        const productSalesHistory = await OrderHistory.aggregate([
            {
                $match: {
                    createdAt: { $gte: monthStart, $lte: monthEnd }
                }
            },
            { $unwind: '$products' },
            {
                $group: {
                    _id: {
                        productId: '$products.productId',
                        week: { $week: '$createdAt' }
                    },
                    name: { $first: '$products.name' },
                    quantity: { $sum: '$products.quantity' },
                    amount: { $sum: { $multiply: ['$products.quantity', '$products.price'] } }
                }
            },
            {
                $group: {
                    _id: '$_id.productId',
                    name: { $first: '$name' },
                    weeklyStats: {
                        $push: {
                            week: '$_id.week',
                            quantity: '$quantity',
                            amount: '$amount'
                        }
                    },
                    totalQuantity: { $sum: '$quantity' },
                    totalAmount: { $sum: '$amount' }
                }
            },
            { $sort: { totalQuantity: -1 } }
        ]);

        res.json({
            success: true,
            data: {
                totalSales: monthlyStats[0]?.totalSales || 0,
                totalAmount: monthlyStats[0]?.totalAmount || 0,
                weeklyStats: weeklyStats.map(stat => ({
                    week: stat._id,
                    salesCount: stat.salesCount,
                    totalAmount: stat.totalAmount
                })),
                paymentMethods: Object.fromEntries(
                    paymentStats.map(stat => [stat._id, stat.totalAmount])
                ),
                topProducts,
                lowStockProducts,
                productSalesHistory
            }
        });

    } catch (error) {
        console.error('Monthly statistics error:', error);
        res.status(500).json({
            success: false,
            message: 'Oylik statistikani olishda xatolik yuz berdi'
        });
    }
});

// 6. Sotuvchilar statistikasi (faqat admin uchun)
router.get('/sellers', verifyToken, async (req, res) => {
    try {
        const { startDate, endDate } = req.query;
        
        // Sana filtrini yaratish
        const dateFilter = {};
        let start, end;
        
        if (startDate && endDate) {
            start = new Date(startDate);
            start.setHours(0, 0, 0, 0);
            end = new Date(endDate);
            end.setHours(23, 59, 59, 999);
            
            dateFilter.createdAt = {
                $gte: start,
                $lte: end
            };
        }

        // Sotuvchilar bo'yicha statistika
        const sellerStats = await OrderHistory.aggregate([
            {
                $match: dateFilter
            },
            {
                $lookup: {
                    from: 'sellers',
                    localField: 'seller',
                    foreignField: '_id',
                    as: 'sellerInfo'
                }
            },
            {
                $unwind: '$sellerInfo'
            },
            {
                $facet: {
                    productStats: [
                        {
                            $unwind: '$products'
                        },
                        {
                            $group: {
                                _id: {
                                    sellerId: '$seller',
                                    sellerName: '$sellerInfo.name',
                                    sellerUsername: '$sellerInfo.username'
                                },
                                totalOrders: { $sum: 1 },
                                totalAmount: { $sum: '$totalSum' },
                                totalProducts: { $sum: '$products.quantity' },
                                productsData: {
                                    $push: {
                                        productId: '$products.productId',
                                        name: '$products.name',
                                        quantity: '$products.quantity',
                                        price: '$products.price',
                                        totalAmount: { $multiply: ['$products.quantity', '$products.price'] },
                                        createdAt: '$createdAt'
                                    }
                                },
                                firstOrderDate: { $min: '$createdAt' },
                                lastOrderDate: { $max: '$createdAt' }
                            }
                        }
                    ],
                    ordersList: [
                        {
                            $group: {
                                _id: {
                                    sellerId: '$seller',
                                    sellerName: '$sellerInfo.name',
                                    sellerUsername: '$sellerInfo.username',
                                    orderId: '$orderId'
                                },
                                order: { 
                                    $first: {
                                        orderId: '$orderId',
                                        totalSum: '$totalSum',
                                        products: '$products',
                                        createdAt: '$createdAt',
                                        status: '$status',
                                        paymentMethod: '$paymentMethod'
                                    }
                                }
                            }
                        },
                        {
                            $group: {
                                _id: {
                                    sellerId: '$_id.sellerId',
                                    sellerName: '$_id.sellerName',
                                    sellerUsername: '$_id.sellerUsername'
                                },
                                orders: {
                                    $push: '$order'
                                }
                            }
                        },
                        {
                            $project: {
                                _id: 0,
                                sellerId: '$_id.sellerId',
                                name: '$_id.sellerName',
                                username: '$_id.sellerUsername',
                                orders: {
                                    $sortArray: {
                                        input: '$orders',
                                        sortBy: { createdAt: -1 }
                                    }
                                }
                            }
                        }
                    ]
                }
            },
            {
                $project: {
                    sellers: {
                        $map: {
                            input: '$productStats',
                            as: 'seller',
                            in: {
                                sellerId: '$$seller._id.sellerId',
                                name: '$$seller._id.sellerName',
                                username: '$$seller._id.sellerUsername',
                                totalOrders: '$$seller.totalOrders',
                                totalAmount: '$$seller.totalAmount',
                                totalProducts: '$$seller.totalProducts',
                                averageOrderAmount: { 
                                    $divide: ['$$seller.totalAmount', '$$seller.totalOrders'] 
                                },
                                firstOrderDate: '$$seller.firstOrderDate',
                                lastOrderDate: '$$seller.lastOrderDate',
                                topProducts: {
                                    $slice: [{
                                        $sortArray: {
                                            input: '$$seller.productsData',
                                            sortBy: { totalAmount: -1 }
                                        }
                                    }, 0, 5]
                                },
                                allProducts: {
                                    $sortArray: {
                                        input: '$$seller.productsData',
                                        sortBy: { totalAmount: -1 }
                                    }
                                },
                                orders: {
                                    $let: {
                                        vars: {
                                            sellerOrders: {
                                                $first: {
                                                    $filter: {
                                                        input: '$ordersList',
                                                        as: 'o',
                                                        cond: { 
                                                            $eq: ['$$o.sellerId', '$$seller._id.sellerId'] 
                                                        }
                                                    }
                                                }
                                            }
                                        },
                                        in: '$$sellerOrders.orders'
                                    }
                                }
                            }
                        }
                    }
                }
            },
            {
                $unwind: '$sellers'
            },
            {
                $sort: { 'sellers.totalAmount': -1 }
            },
            {
                $group: {
                    _id: null,
                    sellers: { $push: '$sellers' }
                }
            }
        ]);

        // Umumiy statistika
        const overallStats = await OrderHistory.aggregate([
            {
                $match: dateFilter
            },
            {
                $group: {
                    _id: null,
                    totalOrders: { $sum: 1 },
                    totalAmount: { $sum: '$totalSum' },
                    averageOrderAmount: { $avg: '$totalSum' },
                    minOrderAmount: { $min: '$totalSum' },
                    maxOrderAmount: { $max: '$totalSum' },
                    firstOrderDate: { $min: '$createdAt' },
                    lastOrderDate: { $max: '$createdAt' }
                }
            },
            {
                $project: {
                    _id: 0,
                    totalOrders: 1,
                    totalAmount: 1,
                    averageOrderAmount: 1,
                    minOrderAmount: 1,
                    maxOrderAmount: 1,
                    firstOrderDate: 1,
                    lastOrderDate: 1
                }
            }
        ]);

        res.json({
            success: true,
            data: {
                sellers: sellerStats[0]?.sellers || [],
                overall: overallStats[0] || {
                    totalOrders: 0,
                    totalAmount: 0,
                    averageOrderAmount: 0,
                    minOrderAmount: 0,
                    maxOrderAmount: 0,
                    firstOrderDate: null,
                    lastOrderDate: null
                },
                dateRange: startDate && endDate ? {
                    startDate: start,
                    endDate: end
                } : null
            }
        });
    } catch (error) {
        console.error('Sellers statistics error:', error);
        res.status(500).json({
            success: false,
            message: 'Sotuvchilar statistikasini olishda xatolik yuz berdi'
        });
    }
});

module.exports = router;
