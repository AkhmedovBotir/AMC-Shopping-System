const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Seller = require('../models/seller.model');
const OrderHistory = require('../models/orderHistory.model');
const { verifyToken, adminAuth } = require('../middleware/auth.middleware');

const router = express.Router();

// Admin mavjudligini tekshirish
const checkAdminExists = async () => {
    const admin = await Seller.findOne({ isAdmin: true });
    return admin !== null;
};

// Admin login
router.post('/admin/login', async (req, res) => {
    try {
        const { username, password } = req.body;

        // Admin mavjudligini tekshirish
        const admin = await Seller.findOne({ username, isAdmin: true });
        if (!admin) {
            return res.status(401).json({ message: 'Admin topilmadi' });
        }

        // Parolni tekshirish
        const isMatch = await bcrypt.compare(password, admin.password);
        if (!isMatch) {
            return res.status(401).json({ message: 'Noto\'g\'ri parol' });
        }

        // Token yaratish
        const token = jwt.sign(
            { 
                _id: admin._id,
                isAdmin: true,
                name: admin.name,
                username: admin.username
            },
            process.env.JWT_SECRET,
            { expiresIn: '24h' }
        );

        res.json({
            token,
            seller: {
                _id: admin._id,
                name: admin.name,
                username: admin.username,
                isAdmin: admin.isAdmin
            }
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Birinchi admin yaratish (faqat birinchi marta)
router.post('/admin/setup', async (req, res) => {
    try {
        // Admin mavjudligini tekshirish
        const adminExists = await checkAdminExists();
        if (adminExists) {
            return res.status(400).json({ 
                message: 'Admin allaqachon mavjud. Faqat bitta admin bo\'lishi mumkin' 
            });
        }

        // Yangi admin yaratish
        const admin = new Seller({
            name: req.body.name,
            username: req.body.username,
            password: req.body.password,
            isAdmin: true
        });

        await admin.save();

        // Token yaratish
        const token = jwt.sign(
            { 
                _id: admin._id,
                isAdmin: true,
                name: admin.name,
                username: admin.username
            },
            process.env.JWT_SECRET,
            { expiresIn: '24h' }
        );

        res.status(201).json({
            token,
            seller: {
                _id: admin._id,
                name: admin.name,
                username: admin.username,
                isAdmin: admin.isAdmin
            }
        });
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Yangi sotuvchi yaratish (faqat admin)
router.post('/', verifyToken, adminAuth, async (req, res) => {
    try {
        // Admin yaratishga urinishni tekshirish
        if (req.body.isAdmin) {
            return res.status(400).json({ 
                message: 'Yangi admin yaratish mumkin emas' 
            });
        }

        const seller = new Seller(req.body);
        await seller.save();
        res.status(201).json({
            id: seller._id,
            name: seller.name,
            username: seller.username
        });
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Sotuvchi login
router.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;

        // Sotuvchini topish
        const seller = await Seller.findOne({ username, isAdmin: false });
        if (!seller) {
            return res.status(401).json({ message: 'Sotuvchi topilmadi' });
        }

        // Parolni tekshirish
        const isMatch = await bcrypt.compare(password, seller.password);
        if (!isMatch) {
            return res.status(401).json({ message: 'Noto\'g\'ri parol' });
        }

        // Token yaratish
        const token = jwt.sign(
            { 
                _id: seller._id,
                isAdmin: false,
                name: seller.name,
                username: seller.username
            },
            process.env.JWT_SECRET,
            { expiresIn: '24h' }
        );

        res.json({
            token,
            seller: {
                _id: seller._id,
                name: seller.name,
                username: seller.username,
                isAdmin: seller.isAdmin
            }
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// O'z profilini olish
router.get('/me', verifyToken, async (req, res) => {
    try {
        const seller = await Seller.findById(req.seller._id);
        if (!seller) {
            return res.status(404).json({ message: 'Sotuvchi topilmadi' });
        }
        res.json({
            id: seller._id,
            name: seller.name,
            username: seller.username,
            isAdmin: seller.isAdmin
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Barcha sotuvchilarni olish (faqat admin)
router.get('/', verifyToken, adminAuth, async (req, res) => {
    try {
        const sellers = await Seller.find({ isAdmin: false })
            .select('-password');
        res.json(sellers);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Sotuvchini yangilash (faqat admin)
router.patch('/:id', verifyToken, adminAuth, async (req, res) => {
    try {
        // Admin statusini o'zgartirishga urinishni tekshirish
        if (req.body.isAdmin !== undefined) {
            return res.status(400).json({ 
                message: 'Admin statusini o\'zgartirish mumkin emas' 
            });
        }

        // Status ni tekshirish
        if (req.body.status && !['active', 'inactive'].includes(req.body.status)) {
            return res.status(400).json({
                message: 'Noto\'g\'ri status. Status faqat "active" yoki "inactive" bo\'lishi mumkin'
            });
        }

        const seller = await Seller.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true }
        ).select('-password');

        if (!seller) {
            return res.status(404).json({ message: 'Sotuvchi topilmadi' });
        }

        res.json(seller);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Sotuvchi parolini yangilash (admin uchun)
router.patch('/:id/password', verifyToken, adminAuth, async (req, res) => {
    try {
        const { newPassword } = req.body;
        
        if (!newPassword || newPassword.length < 6) {
            return res.status(400).json({ 
                message: 'Parol kamida 6 ta belgidan iborat bo\'lishi kerak' 
            });
        }

        const seller = await Seller.findById(req.params.id);
        if (!seller) {
            return res.status(404).json({ message: 'Sotuvchi topilmadi' });
        }

        seller.password = newPassword;
        await seller.save();

        // WebSocket orqali xabar yuborish
        if (req.wsHandlers) {
            req.wsHandlers.notifySellerUpdated(seller._id);
        }

        res.json({ message: 'Sotuvchi paroli muvaffaqiyatli yangilandi' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Sotuvchini o'chirish (faqat admin uchun)
router.delete('/:id', verifyToken, adminAuth, async (req, res) => {
    try {
        const seller = await Seller.findByIdAndDelete(req.params.id);
        
        if (!seller) {
            return res.status(404).json({ message: 'Sotuvchi topilmadi' });
        }

        // WebSocket orqali xabar yuborish
        if (req.wsHandlers) {
            req.wsHandlers.notifySellerDeleted(seller._id);
        }

        res.json({ message: 'Sotuvchi muvaffaqiyatli o\'chirildi' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
