const express = require('express');
const mongoose = require('mongoose');
const Category = require('../models/category.model');
const Product = require('../models/product.model');
const { verifyToken, adminAuth } = require('../middleware/auth.middleware');

const router = express.Router();

// Yangi kategoriya yaratish (faqat admin)
router.post('/', verifyToken, adminAuth, async (req, res) => {
    try {
        const category = new Category(req.body);
        await category.save();
        res.status(201).json(category);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Kategoriyaga subkategoriya qo'shish (faqat admin)
router.post('/:categoryId/subcategories', verifyToken, adminAuth, async (req, res) => {
    try {
        const { categoryId } = req.params;

        // CategoryId validatsiyasi
        if (!categoryId || !mongoose.Types.ObjectId.isValid(categoryId)) {
            return res.status(400).json({ 
                message: 'Kategoriya ID si noto\'g\'ri formatda' 
            });
        }

        const category = await Category.findById(categoryId);
        if (!category) {
            return res.status(404).json({ message: 'Kategoriya topilmadi' });
        }

        // Subkategoriya nomini tekshirish
        const { name, description } = req.body;
        if (!name) {
            return res.status(400).json({ 
                message: 'Subkategoriya nomi kiritilishi shart' 
            });
        }

        // Subkategoriya nomi unique bo'lishi kerak
        const existingSubcategory = category.subcategories.find(
            sub => sub.name.toLowerCase() === name.toLowerCase()
        );
        if (existingSubcategory) {
            return res.status(400).json({ 
                message: 'Bu nomli subkategoriya allaqachon mavjud' 
            });
        }

        // Yangi subkategoriya qo'shish
        const subcategory = {
            _id: new mongoose.Types.ObjectId(),
            name,
            description
        };

        category.subcategories.push(subcategory);
        await category.save();

        // WebSocket orqali xabar yuborish
        if (req.wsHandlers) {
            req.wsHandlers.notifySubcategoryCreated(categoryId, subcategory);
        }

        res.status(201).json({
            message: 'Subkategoriya qo\'shildi',
            subcategory
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Barcha kategoriyalarni olish
router.get('/', verifyToken, async (req, res) => {
    try {
        const categories = await Category.find();
        res.json(categories);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Barcha kategoriyalar, subkategoriyalar va mahsulotlarni olish
router.get('/with-products', async (req, res) => {
    try {
        const categories = await Category.find();
        const result = [];

        for (const category of categories) {
            const categoryData = {
                _id: category._id,
                name: category.name,
                description: category.description,
                subcategories: []
            };

            // Har bir subkategoriya uchun mahsulotlarni olish
            for (const subcategory of category.subcategories) {
                const products = await Product.find({
                    category: category._id,
                    subcategory: subcategory._id
                }).select('name price unit unitSize inventory');

                categoryData.subcategories.push({
                    _id: subcategory._id,
                    name: subcategory.name,
                    description: subcategory.description,
                    products: products
                });
            }

            // Asosiy kategoriyaga tegishli mahsulotlar (subkategoriyasiz)
            const mainProducts = await Product.find({
                category: category._id,
                subcategory: { $exists: false }
            }).select('name price unit unitSize inventory');

            if (mainProducts.length > 0) {
                categoryData.products = mainProducts;
            }

            result.push(categoryData);
        }

        res.json({
            success: true,
            data: result
        });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: error.message 
        });
    }
});

// Kategoriyani ID bo'yicha olish
router.get('/:id', verifyToken, async (req, res) => {
    try {
        const category = await Category.findById(req.params.id);
        if (!category) {
            return res.status(404).json({ message: 'Kategoriya topilmadi' });
        }
        res.json(category);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Kategoriyani yangilash (faqat admin)
router.patch('/:id', verifyToken, adminAuth, async (req, res) => {
    try {
        const category = await Category.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true }
        );
        if (!category) {
            return res.status(404).json({ message: 'Kategoriya topilmadi' });
        }
        res.json(category);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Subkategoriyani yangilash (faqat admin)
router.put('/subcategories/:subcategoryId', verifyToken, adminAuth, async (req, res) => {
    try {
        // SubcategoryId validatsiyasi
        if (!mongoose.Types.ObjectId.isValid(req.params.subcategoryId)) {
            return res.status(400).json({ 
                success: false,
                message: 'Noto\'g\'ri subkategoriya ID formati' 
            });
        }

        const { name, description } = req.body;
        if (!name) {
            return res.status(400).json({ 
                success: false,
                message: 'Subkategoriya nomi kiritilishi shart' 
            });
        }

        // Kategoriyani topish va subkategoriyani tekshirish
        const category = await Category.findOne({
            'subcategories._id': req.params.subcategoryId
        });

        if (!category) {
            return res.status(404).json({ 
                success: false,
                message: 'Subkategoriya topilmadi' 
            });
        }

        // Subkategoriya nomini tekshirish
        const existingSubcategory = category.subcategories.find(
            sub => sub.name.toLowerCase() === name.toLowerCase() && 
                  sub._id.toString() !== req.params.subcategoryId
        );

        if (existingSubcategory) {
            return res.status(400).json({ 
                success: false,
                message: 'Bu nomli subkategoriya allaqachon mavjud' 
            });
        }

        // Subkategoriyani yangilash
        const subcategory = category.subcategories.id(req.params.subcategoryId);
        subcategory.name = name;
        subcategory.description = description || '';

        // Saqlash
        await category.save();

        res.json({
            success: true,
            message: 'Subkategoriya yangilandi',
            data: subcategory
        });

    } catch (error) {
        console.error('Subkategoriya yangilash xatosi:', error);
        res.status(400).json({ 
            success: false,
            message: error.message 
        });
    }
});

// Subkategoriyani qisman yangilash (faqat admin)
router.patch('/subcategories/:subcategoryId', verifyToken, adminAuth, async (req, res) => {
    try {
        // SubcategoryId validatsiyasi
        if (!mongoose.Types.ObjectId.isValid(req.params.subcategoryId)) {
            return res.status(400).json({ 
                success: false,
                message: 'Noto\'g\'ri subkategoriya ID formati' 
            });
        }

        // Kategoriyani topish va subkategoriyani tekshirish
        const category = await Category.findOne({
            'subcategories._id': req.params.subcategoryId
        });

        if (!category) {
            return res.status(404).json({ 
                success: false,
                message: 'Subkategoriya topilmadi' 
            });
        }

        // Subkategoriya nomini tekshirish (agar yangi nom berilgan bo'lsa)
        if (req.body.name) {
            const existingSubcategory = category.subcategories.find(
                sub => sub.name.toLowerCase() === req.body.name.toLowerCase() && 
                      sub._id.toString() !== req.params.subcategoryId
            );

            if (existingSubcategory) {
                return res.status(400).json({ 
                    success: false,
                    message: 'Bu nomli subkategoriya allaqachon mavjud' 
                });
            }
        }

        // Subkategoriyani yangilash
        const subcategory = category.subcategories.id(req.params.subcategoryId);
        Object.assign(subcategory, req.body);

        // Saqlash
        await category.save();

        res.json({
            success: true,
            message: 'Subkategoriya yangilandi',
            data: subcategory
        });

    } catch (error) {
        console.error('Subkategoriya yangilash xatosi:', error);
        res.status(400).json({ 
            success: false,
            message: error.message 
        });
    }
});

// Kategoriyani o'chirish (faqat admin)
router.delete('/:id', verifyToken, adminAuth, async (req, res) => {
    try {
        const category = await Category.findByIdAndDelete(req.params.id);
        if (!category) {
            return res.status(404).json({ message: 'Kategoriya topilmadi' });
        }
        res.json({ message: 'Kategoriya o\'chirildi' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Subkategoriyani o'chirish (faqat admin)
router.delete('/:categoryId/subcategories/:subcategoryId', verifyToken, adminAuth, async (req, res) => {
    try {
        const category = await Category.findById(req.params.categoryId);
        if (!category) {
            return res.status(404).json({ message: 'Kategoriya topilmadi' });
        }

        category.subcategories = category.subcategories.filter(
            sub => sub._id.toString() !== req.params.subcategoryId
        );
        await category.save();
        
        res.json({ message: 'Subkategoriya o\'chirildi' });
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

module.exports = router;
