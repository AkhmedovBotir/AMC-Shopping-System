const express = require('express');
const Sale = require('../models/sale.model');
const { verifyToken, adminAuth } = require('../middleware/auth.middleware');

const router = express.Router();

// Yangi sotuv yaratish
router.post('/', verifyToken, async (req, res) => {
    try {
        const sale = new Sale({
            ...req.body,
            seller: req.seller._id // Avtorizatsiya qilingan sotuvchini qo'shish
        });
        await sale.save();
        await sale.populate('product seller');

        // WebSocket orqali xabar yuborish
        req.wsHandlers.broadcastNewSale(sale);
        
        res.status(201).json(sale);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Barcha sotuvlarni olish (faqat admin)
router.get('/', verifyToken, adminAuth, async (req, res) => {
    try {
        const sales = await Sale.find()
            .populate('product', 'name type properties')
            .populate('seller', 'name');
        res.json(sales);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Sotuvni ID bo'yicha olish
router.get('/:id', verifyToken, async (req, res) => {
    try {
        const sale = await Sale.findOne({
            _id: req.params.id,
            $or: [
                { seller: req.seller._id }, // O'zining sotuvi
                { isAdmin: true } // Admin uchun barcha sotuvlar
            ]
        })
        .populate('product', 'name type properties')
        .populate('seller', 'name');

        if (!sale) {
            return res.status(404).json({ message: 'Sotuv topilmadi' });
        }
        res.json(sale);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Sotuvchi bo'yicha sotuvlarni olish
router.get('/seller/:sellerId', verifyToken, async (req, res) => {
    try {
        // Faqat o'zining sotuvlarini yoki admin bo'lsa barcha sotuvlarni ko'rish
        if (!req.seller.isAdmin && req.params.sellerId !== req.seller._id.toString()) {
            return res.status(403).json({ message: 'Sizda bu ma\'lumotlarni ko\'rish huquqi yo\'q' });
        }

        const sales = await Sale.find({ seller: req.params.sellerId })
            .populate('product', 'name type properties')
            .populate('seller', 'name');
        res.json(sales);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Statistika (faqat admin)
router.get('/statistics/summary', verifyToken, adminAuth, async (req, res) => {
    try {
        const stats = await Sale.aggregate([
            {
                $lookup: {
                    from: 'products',
                    localField: 'product',
                    foreignField: '_id',
                    as: 'product'
                }
            },
            {
                $unwind: '$product'
            },
            {
                $group: {
                    _id: {
                        product: '$product._id',
                        productName: '$product.name',
                        productType: '$product.type'
                    },
                    totalQuantity: { $sum: '$quantity' },
                    totalSales: { $sum: 1 }
                }
            }
        ]);
        
        res.json(stats);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
