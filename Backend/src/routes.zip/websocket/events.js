// WebSocket event nomlari
module.exports = {
    // Admin events
    ADMIN_CONNECTED: 'admin_connected',
    ADMIN_DISCONNECTED: 'admin_disconnected',

    // Sotuvchi events
    SELLER_CONNECTED: 'seller_connected',
    SELLER_DISCONNECTED: 'seller_disconnected',
    SELLER_LOGIN: 'seller_login',
    SELLER_LOGOUT: 'seller_logout',

    // Kategoriya events
    CATEGORY_CREATED: 'category_created',
    CATEGORY_UPDATED: 'category_updated',
    CATEGORY_DELETED: 'category_deleted',
    SUBCATEGORY_ADDED: 'subcategory_added',
    SUBCATEGORY_UPDATED: 'subcategory_updated',
    SUBCATEGORY_DELETED: 'subcategory_deleted',

    // Mahsulot events
    PRODUCT_CREATED: 'product_created',
    PRODUCT_UPDATED: 'product_updated',
    PRODUCT_DELETED: 'product_deleted',
    PRODUCT_INVENTORY_UPDATED: 'product_inventory_updated'
};
