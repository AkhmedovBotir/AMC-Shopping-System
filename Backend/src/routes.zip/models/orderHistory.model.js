const mongoose = require('mongoose');

const orderHistorySchema = new mongoose.Schema({
    orderId: {
        type: Number,
        required: true,
        index: true
    },
    computerId: {
        type: String,
        index: true
    },
    seller: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Seller',
        required: true,
        index: true
    },
    products: [{
        productId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Product',
            required: true
        },
        name: {
            type: String,
            required: true
        },
        quantity: {
            type: Number,
            required: true,
            min: 1
        },
        price: {
            type: Number,
            required: true,
            min: 0
        },
        unit: {
            type: String,
            required: true
        },
        unitSize: {
            type: Number,
            required: true
        }
    }],
    totalSum: {
        type: Number,
        required: true,
        min: 0
    },
    status: {
        type: String,
        enum: ['completed', 'cancelled'],
        default: 'completed'
    },
    completedAt: {
        type: Date
    },
    paymentMethod: {
        type: String,
        enum: ['cash', 'card'],
        default: 'cash'
    }
}, {
    timestamps: true
});

// Indekslar
orderHistorySchema.index({ createdAt: -1 });
orderHistorySchema.index({ seller: 1, createdAt: -1 });
orderHistorySchema.index({ status: 1, createdAt: -1 });

module.exports = mongoose.model('OrderHistory', orderHistorySchema);
