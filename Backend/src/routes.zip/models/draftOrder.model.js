const mongoose = require('mongoose');
const Counter = require('./counter.model');

const draftOrderSchema = new mongoose.Schema({
    orderId: {
        type: Number,
        unique: true
    },
    computerId: {
        type: Number,
        index: true
    },
    seller: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Seller',
        required: true
    },
    table: {
        type: String,
        trim: true,
        default: null
    },
    products: [{
        productId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Product',
            required: true
        },
        name: {
            type: String,
            required: true
        },
        quantity: {
            type: Number,
            required: true,
            min: 1
        },
        price: {
            type: Number,
            required: true,
            min: 0
        },
        unit: {
            type: String
        },
        unitSize: {
            type: Number
        }
    }],
    status: {
        type: String,
        enum: ['draft', 'completed'],
        default: 'draft'
    },
    totalSum: {
        type: Number,
        required: true,
        min: 0
    },
    timestamp: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date,
        default: Date.now
    }
});

// Update updatedAt timestamp before save
draftOrderSchema.pre('save', async function(next) {
    this.updatedAt = new Date();
    
    // Agar orderId yo'q bo'lsa, yangi ID olish
    if (!this.orderId) {
        try {
            const counter = await Counter.findByIdAndUpdate(
                { _id: 'draftOrderId' },
                { $inc: { seq: 1 } },
                { new: true, upsert: true }
            );
            this.orderId = counter.seq;
        } catch (error) {
            return next(error);
        }
    }
    next();
});

module.exports = mongoose.model('DraftOrder', draftOrderSchema);
